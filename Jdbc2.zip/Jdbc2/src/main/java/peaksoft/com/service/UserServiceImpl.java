package peaksoft.com.service;

import peaksoft.com.Dao.Dao;

public class UserServiceImpl implements UserService{
    Dao userDao = new Dao();
        @Override
        public void seveUser(String name, String lastName, byte age) {
            userDao.seveUser(name,lastName,age);
        }
}

