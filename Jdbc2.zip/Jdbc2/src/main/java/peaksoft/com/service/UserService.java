package peaksoft.com.service;

public interface UserService {
    void seveUser(String name,String lastName,byte age);
}
