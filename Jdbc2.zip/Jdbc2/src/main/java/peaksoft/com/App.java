package peaksoft.com;

import peaksoft.com.service.UserService;
import peaksoft.com.service.UserServiceImpl;

public class App
{
    public static void main( String[] args )
    {
        UserService userService = new UserServiceImpl();
        userService.seveUser("akyl","nerbekov",(byte) 21);
    }
}
