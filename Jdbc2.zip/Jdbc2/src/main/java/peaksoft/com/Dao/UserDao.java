package peaksoft.com.Dao;

public interface UserDao {
    void seveUser(String name, String lastName, byte age);
}
