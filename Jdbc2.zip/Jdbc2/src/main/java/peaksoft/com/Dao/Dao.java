package peaksoft.com.Dao;
import peaksoft.com.util.Util;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Dao implements UserDao {


    @Override
    public void seveUser(String name, String lastName, byte age) {
        String SQL ="INSERT INTO user_dao(name,lastname,age) VALUES(?,?,?)";

        try(Connection conn =Util.connection();
            PreparedStatement prstmt = conn.prepareStatement(SQL)){
            prstmt.setString(1,name);
            prstmt.setString(2,lastName);
            prstmt.setByte(3,age);
            prstmt.executeUpdate();
            System.out.println(name+"  базага кашулду");
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }
}

